/**
*
*	Ideas:
*	- We don't always have access to the hardware, so we may need to "simulate" our code & logic on our computers.
*	- We may dedicate a certain part of our code (since this is a single file project, it's natural for it to be the beginning part) for abstraction of input&output to our system.
*		This helps us write the logic part of our code only once, and we can test it on multiple platforms by only defining an appropriate I/O for them.
*	- Defining some data structures & helper functions may reduce the overall length of the required code. We may organize them and put them together as well. 
*
*	Ideas for the actual problem-related code:
*	- We can assume the middle servo angle to be 0, do all the math however we like, and convert it to some other form right before supplying to another system (i.e. PWM Controller).
*	- We can write our code only for one half of the servo's angle range, then mirror the values at the end as appropriate.
*	- We want "realistic" movement, so the animations will need to have varying movement speeds. We can describe these movements using curves with easing.
*	- At any time, we can infer what the servo angle should be by looking at the curve information and the current time.
*	- We may need to use multiple animations with different curves in order to describe the movements that occur during an attack. 
*	- We also need to do things like toggling the mirroring at the correct times.
*	- There can be many solutions, and in this one we make use of a job queue (task queue).
*	- Our jobs (tasks) have many properties and states. Each job type has its own handler.
*	- Since most of the things we need to do happen in a certain sequence, our job queue will be blocking (we don't move on to the next job until the current one is finished).
*	- A job can create and add many jobs to the queue. The job gets removed from the queue when it's finished.
*
*	Now you can read the code!
*
*	Needs -lm flag when compiling on Linux
*
*/

// Determine platform
#define PLATFORM_WIN 0
#define PLATFORM_MCU 0
#define PLATFORM_OSX 0
#define PLATFORM_LINUX 0
#if defined(_WIN32)
	#undef PLATFORM_WIN
	#define PLATFORM_WIN 1
#elif defined(USE_HAL_DRIVER)
	#undef PLATFORM_MCU
	#define PLATFORM_MCU 1

#elif defined(__MACH__)
	#undef PLATFORM_OSX
	#define PLATFORM_OSX 1
#elif defined(__linux__)
	#undef PLATFORM_LINUX
	#define PLATFORM_LINUX 1
#else
	#error GGWP
#endif 

// Includes
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdint.h>
#if PLATFORM_MCU
	#include "main.h"
	#include "dma.h"
	#include "tim.h"
	#include "gpio.h"
	//#include "usart.h"
#elif PLATFORM_WIN
	#include <windows.h>
	#include <stdio.h>
	#include <conio.h>
	#include <time.h>
#elif PLATFORM_OSX || PLATFORM_LINUX
	#include <stdio.h>
	#include <time.h>
	#include <termios.h>
	#include <unistd.h>
	#include <fcntl.h>
#endif

// Some compilers don't have it defined
#ifndef M_PI
	#define M_PI   3.14159265358979323846264338327950288
#endif
// These are helpful
#ifndef min
	#define min(a, b) ((a) < (b) ? (a) : (b))
#endif
#ifndef max
	#define max(a, b) ((a) < (b) ? (b) : (a))
#endif

//=========================================
//=========================================
// For abstraction purposes
//=========================================

int32_t INPUT_TIME = -1;
bool INPUT_BUTTONS[3];

int32_t CURRENT_TIME;
bool BUTTONS[3] = {0};
bool LAST_BUTTONS[3] = {0};

bool LEDS[3] = {0};
bool BUZZER_STATE = false;
float SERVO_ANGLE = 0.0f;

#if PLATFORM_MCU
#elif PLATFORM_OSX || PLATFORM_LINUX
	// You don't need to understand this function
	char readCharNonBlocking() {
		struct termios t;
		tcgetattr(STDIN_FILENO, &t);
		t.c_lflag &= ~(ICANON | ECHO);
		tcsetattr(STDIN_FILENO, TCSANOW, &t);
		fd_set fs;
		FD_ZERO(&fs);
		FD_SET(STDIN_FILENO, &fs);
		struct timeval tv = {0, 0};
		select(STDIN_FILENO + 1, &fs, 0, 0, &tv);
		if (FD_ISSET(STDIN_FILENO, &fs)) return getchar();
		else return 0;
	}
#endif
void init() {
	#if PLATFORM_MCU
		HAL_GPIO_InitPin(LED1_GPIO_Port, LED1_Pin, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL);
		HAL_GPIO_InitPin(LED2_GPIO_Port, LED2_Pin, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL);
		HAL_GPIO_InitPin(LED3_GPIO_Port, LED3_Pin, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL);
		HAL_GPIO_InitPin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL);
		HAL_GPIO_InitPin(BUTTON1_GPIO_Port, BUTTON1_Pin, GPIO_MODE_INPUT, GPIO_PULLUP);
		HAL_GPIO_InitPin(BUTTON2_GPIO_Port, BUTTON2_Pin, GPIO_MODE_INPUT, GPIO_PULLUP);
		HAL_GPIO_InitPin(BUTTON3_GPIO_Port, BUTTON3_Pin, GPIO_MODE_INPUT, GPIO_PULLUP);
		TIM5_PWM_Init();
		HAL_TIM_ConfigTimer(SERVO_TIM, 23, 59999);
		HAL_TIM_PWM_Start(SERVO_TIM, TIM_CHANNEL_1);
	#endif
}

void input() {
	#if PLATFORM_MCU
		INPUT_BUTTONS[0] = !HAL_GPIO_ReadPin(BUTTON1_GPIO_Port, BUTTON1_Pin);
		INPUT_BUTTONS[1] = !HAL_GPIO_ReadPin(BUTTON2_GPIO_Port, BUTTON2_Pin);
		INPUT_BUTTONS[2] = !HAL_GPIO_ReadPin(BUTTON3_GPIO_Port, BUTTON3_Pin);
		INPUT_TIME = HAL_GetTick();
	#elif PLATFORM_WIN
		if (kbhit()) getch();
		INPUT_BUTTONS[0] = GetAsyncKeyState('Z') & (1 << 15);
		INPUT_BUTTONS[1] = GetAsyncKeyState('X') & (1 << 15);
		INPUT_BUTTONS[2] = GetAsyncKeyState('C') & (1 << 15);
		INPUT_TIME = clock() / (CLOCKS_PER_SEC/1000);
	#elif PLATFORM_OSX || PLATFORM_LINUX
		char c = readCharNonBlocking();
		INPUT_BUTTONS[0] |= c == 'z';
		INPUT_BUTTONS[1] |= c == 'x';
		INPUT_BUTTONS[2] |= c == 'c';
		if (c == ' ') for (int i = 0; i < 3; i++) INPUT_BUTTONS[i] = false;
		INPUT_TIME = clock() / (CLOCKS_PER_SEC/1000);
	#endif
	CURRENT_TIME = INPUT_TIME; // Redundant variable, but not a big deal and the separation of 'abstracted inputs' and variables that are directly accessed inside the logic part feels better. But it's a personal preference.
}

void output() {
	#if PLATFORM_MCU
		HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, LEDS[0]);
		HAL_GPIO_WritePin(LED2_GPIO_Port, LED2_Pin, LEDS[1]);
		HAL_GPIO_WritePin(LED3_GPIO_Port, LED3_Pin, LEDS[2]);
		HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, BUZZER_STATE);
		int32_t safeguard = 4500 + 3000 * (SERVO_ANGLE/(M_PI/2));
		safeguard = min(7500, safeguard);
		safeguard = max(1500, safeguard);
		HAL_TIM_PWM_SetCompare(SERVO_TIM, TIM_CHANNEL_1, safeguard);
	#elif PLATFORM_WIN || PLATFORM_OSX || PLATFORM_LINUX
		if (PLATFORM_WIN) system("cls");
		else {
			printf("\e[1;1H\e[2J"); // clears screen
			printf("Due to technical limitations on OSX/Linux, you need to press Spacebar to \"release\" buttons.\n");
		}
		printf("Time: %dms\nLEDs & Buzzer: (%d) (%d) (%d) z%dz\n", CURRENT_TIME, LEDS[0], LEDS[1], LEDS[2], BUZZER_STATE);
		printf("Buttons: [%d] [%d] [%d] (zxc)\n", BUTTONS[0], BUTTONS[1], BUTTONS[2]);
		const int numBlocks = 72;
		int block = (sin(SERVO_ANGLE)+1) * numBlocks/2;
		printf(" sin(angle) ");
		for (int i = 0; i < numBlocks; i++) printf("%c", i == block ? 'O' : (i == numBlocks/2 ? '|' : '-')); 
		printf(" sin(angle) \nServo: %.2f*(pi/2)\n", SERVO_ANGLE/M_PI*2);
	#endif

}

//=========================================
// End of "For abstraction purposes"
//=========================================
//=========================================

#define LOOP_MS 16

void controllerInit();
void controllerUpdate();

int pwmhomework() {
	
	init();
	controllerInit();

	int32_t lastTime = -LOOP_MS;
	while (true) {
		while (CURRENT_TIME - lastTime < LOOP_MS) input(); // Time is also an input
		lastTime = CURRENT_TIME;
		for (int i = 0; i < 3; i++) LAST_BUTTONS[i] = BUTTONS[i];
		for (int i = 0; i < 3; i++) BUTTONS[i] = INPUT_BUTTONS[i];

		controllerUpdate();

		output();
	}
}

// Now we don't need to care about the platform the code will run on


//=========================================
//=========================================
// Generic Helpers
//=========================================

// A simple linked list node
typedef struct LLnodeT {
	struct LLnodeT *next;
	void *data;
} LLnode;
LLnode* LLnodeCreate(void *data) {
	LLnode *ret = (LLnode*)malloc(sizeof(LLnode));
	ret->next = NULL;
	ret->data = data;
	return ret;
}

// A simple queue
typedef struct {
	LLnode *head, *tail;
} Queue;
bool QueueEmpty(Queue *q) { return q->head == NULL; }
void QueuePush(Queue *q, void *data) {
	if (q->tail == NULL) q->head = q->tail = LLnodeCreate(data);
	else q->tail = q->tail->next = LLnodeCreate(data);
}
void* QueueFront(Queue *q) {
	return q->head->data;
}
void* QueuePop(Queue *q) {
	void *ret = q->head->data;
	LLnode *toDelete = q->head;
	q->head = q->head->next;
	if (q->head == NULL) q->tail = NULL;
	free(toDelete);
	return ret;
}
int32_t QueueLength(Queue *q) {
	int32_t ret = 0;
	LLnode *p = q->head;
	while (p != NULL) {
		p = p->next;
		ret++;
	}
	return ret;
}

// For "realistic":) movement
typedef enum {
	LINEAR,
	POLY_EASE_IN,
	POLY_EASE_OUT,
	POLY_EASE_IN_OUT
} AnimCurve;
float curveFunction(float beginVal, float endVal, float duration, float passedTime, AnimCurve curve, float exponent) {
	if (curve == LINEAR) return beginVal + (endVal - beginVal) * passedTime / duration;
	else if (curve == POLY_EASE_IN) return beginVal + (endVal - beginVal) * powf(passedTime/duration, exponent);
	else if (curve == POLY_EASE_OUT) return curveFunction(endVal, beginVal, duration, duration-passedTime, POLY_EASE_IN, exponent);
	else if (curve == POLY_EASE_IN_OUT) {
		if (passedTime <= duration/2) return curveFunction(beginVal, beginVal+(endVal-beginVal)/2, duration/2, passedTime, POLY_EASE_IN, exponent);
		else return curveFunction(endVal, endVal+(beginVal-endVal)/2, duration/2, duration-passedTime, POLY_EASE_OUT, exponent);
	} else return beginVal; // This shouldn't happen
}

//=========================================
// End of "Generic Helpers"
//=========================================
//=========================================

// Now we have quite some useful structures/functions.


// Some definitions
#define RESTING_ANGLE (M_PI/3)
#define EXTENDED_ANGLE (M_PI/2)
#define CHARGED_OVERSHOOT_OFFSET (M_PI/12)
#define MAX_COMBO_LENGTH 256
const char COMBO_SEQUENCES[][MAX_COMBO_LENGTH] = {"LLLL", "LLLH", "HHH", "HHLH"};
const int32_t COMBO_POINTS[] = {0, 1, 0, 1};

// Some global variables
char attackHistory[MAX_COMBO_LENGTH]; // The rightmost element / element with the highest address refers to the most recent attack.
void comboBreak() { attackHistory[MAX_COMBO_LENGTH-1] = 0; }
int32_t comboCounter = 0;
float oneSidedServoAngle = RESTING_ANGLE; // We only use positive angles and mirror them when needed, so that we don't need elaborate logic when creating animations jobs
bool shouldMirror = true; // This one is toggled every time we hit the target
bool chargingPermitted = false; // For charging to occur, the heavy attack button shouldn't be released, even while the heavy attack (its chargable phase) is still not in front of the queue

// Buzzer logic
typedef struct {
	int32_t onTime, offTime, repeat, lastBeginTime;
} BuzzerState;
BuzzerState buzzerState = {0, 0, 0, 0};
bool buzzerIsOn() {
	return CURRENT_TIME - buzzerState.lastBeginTime < buzzerState.onTime;
}
void buzzerUpdate() {
	if (CURRENT_TIME - buzzerState.lastBeginTime > buzzerState.onTime + buzzerState.offTime) {
		buzzerState.repeat = max(0, buzzerState.repeat-1);
		if (buzzerState.repeat > 0) buzzerState.lastBeginTime += buzzerState.onTime + buzzerState.offTime;
	}
}

// Enumerating the buttons and some shortcut functions
typedef enum {
	BTN_LIGHT,
	BTN_HEAVY,
	BTN_SPECIAL
} Button;
bool risingEdge(Button btn) { return BUTTONS[btn] && !LAST_BUTTONS[btn]; }
bool fallingEdge(Button btn) { return !BUTTONS[btn] && LAST_BUTTONS[btn]; }

// Defining the jobs
typedef enum {
	JOB_SIMPLE, // Animation, chaining
	JOB_CHARGER, // First part of Heavy Attack
	JOB_HIT, // Mirroring, combo detection
	NUM_JOBS
} JobType;
typedef struct {
	JobType type;
	char attackType; // relevant to only JOB_HIT
	float bgnVal; // (angle) value associated with beginTime
	float endVal; // (angle) value associated with beginTime+duration
	float brkVal; // (angle) value that indicates the end of the job (brk=break), equal to endVal most of the time
	int32_t beginTime, duration; // some temporal properties of the animation
	AnimCurve curve; // regarding the shape of the animation curve
	float easingExponent; // the exponent that is used if the curve is eased
	bool beginTimeLocked; // this is set to indicate that beginTime should not be overwritten (this is also used while chaining)
	bool chainable; // whether an attack request should be queued or discarded, relevant to only JOB_SIMPLE
	int32_t activationTime; // the time the job reaches the front of the queue, relevant to only JOB_CHARGER
	bool activationTimeLocked; // this is set to indicate that activationTime should not be overwritten, relevant to only JOB_CHARGER
	bool charged; // relevant to only JOB_CHARGER;
} Job;
Queue jobQueue = {NULL, NULL};

// Job handler functions. True as the return value means that the job has been finished (did not block in this iteration)
bool simpleJobHandler(Job *job);
bool chargerJobHandler(Job *job);
bool hitJobHandler(Job *job);
bool (*jobHandlers[NUM_JOBS])(Job *job); // An array of pointers to functions that return bool and take one pointer to job as parameter

// May add appropriate jobs to the queue, returns first added job if any
Job* acceptAttackRequests();

// Helpers for adding jobs to the queue
Job* addLightAttack();
Job* addChargedHeavyAttack();
Job* addUnchargedHeavyAttack();
Job* addHeavyAttackCharger();
Job* addSpecialAttack();

// Some setting up
void controllerInit() {
	// Init job handlers
	jobHandlers[JOB_SIMPLE] = simpleJobHandler;
	jobHandlers[JOB_CHARGER] = chargerJobHandler;
	jobHandlers[JOB_HIT] = hitJobHandler;
	
	comboBreak();
}

// The main function that coordinates the work
void controllerUpdate() {

	// Charging permission is lost (if it existed) when Heavy Attack button is released
	if (!BUTTONS[BTN_HEAVY]) chargingPermitted = false;

	// Execute jobs (while they exist) until blocked
	while (!QueueEmpty(&jobQueue)) {
		Job *job = (Job*)QueueFront(&jobQueue);
		if (!job->beginTimeLocked) { // If this job was chained, then this lock will be already set
			job->beginTime = CURRENT_TIME;
			job->beginTimeLocked = true;
		}
		if (!job->activationTimeLocked) { // Runs for all types of jobs, but only really relevant for the Charger job.
			job->activationTime = CURRENT_TIME;
			job->activationTimeLocked = true;
		}
		bool done = jobHandlers[job->type](job);
		if (done) {
			QueuePop(&jobQueue);
			free(job);
		} else break; // the job blocks
	}

	// No job left means combo chain is broken, also should check attack requests
	if (QueueEmpty(&jobQueue)) {
		comboBreak();
		acceptAttackRequests();
	}

	// Buzzer has its own update logic
	buzzerUpdate();

	// Output
	BUZZER_STATE = buzzerIsOn();
	SERVO_ANGLE = shouldMirror ? -oneSidedServoAngle : oneSidedServoAngle;
	for (int i = 0; i < 3; i++) LEDS[i] = i < comboCounter;

	// Debug
	#if !PLATFORM_MCU
		printf("\nJob queue has %d items\n", QueueLength(&jobQueue));
	#endif
}


bool simpleJobHandler(Job *job) {

	// Make sure t stays in boundary to prevent overshoot
	int32_t t = min(job->duration, CURRENT_TIME - job->beginTime);

	// Accepting attacks (queueing them) and the chaining logic
	if (job->chainable) {
		Job *chained = acceptAttackRequests();
		if (chained != NULL) job->chainable = false; // Accept only once
		if (chained != NULL && chained->endVal > job->endVal) {
			// For smoothing the animation. I think it's good enough, but could be better.
			job->endVal = chained->endVal;
			job->duration += 2* t * chained->duration / job->duration;
			// Note that even if we increase the duration, the job will end when brkVal is reached.
			// We also need to update chained's properties for smoothness
			chained->bgnVal = job->bgnVal;
			chained->duration = job->duration;
			chained->beginTime = job->beginTime;
			chained->beginTimeLocked = true;
			chained->curve = job->curve;
			chained->easingExponent = job->easingExponent;
		}
	}

	// Calculate servo angle
	float val = curveFunction(job->bgnVal, job->endVal, job->duration, t, job->curve, job->easingExponent);
	oneSidedServoAngle = val;

	// Return when almost-or-more complete
	return fabsf(val - job->brkVal) < 1e-6 /*almost*/||/*more*/ (val - job->brkVal) * (job->bgnVal - job->brkVal) < 0;
}
bool chargerJobHandler(Job *job) {

	// Limit "passed time" for curve function
	int32_t t = min(job->duration, CURRENT_TIME - job->beginTime);

	// Calculate servo angle
	float val = curveFunction(job->bgnVal, job->endVal, job->duration, t, job->curve, job->easingExponent);
	oneSidedServoAngle = val;

	// Charging
	if (chargingPermitted && CURRENT_TIME - job->activationTime >= 2000 && !job->charged) {
		job->charged = true;
		buzzerState = (BuzzerState){200, 66, 2, CURRENT_TIME}; // Notify user about the attack being charged
	}

	if (job->charged && !BUTTONS[BTN_HEAVY]) {
		return addChargedHeavyAttack();
	} else if ( !chargingPermitted && (fabsf(val - job->brkVal) < 1e-6 || (val - job->brkVal) * (job->bgnVal - job->brkVal) < 0) ) {
		return addUnchargedHeavyAttack();
	} else
		return false;
}
bool hitJobHandler(Job *job) {
	buzzerState = (BuzzerState){200, 0, 1, CURRENT_TIME}; // Notify user about hitting the target

	shouldMirror = !shouldMirror; // Flipping sides when crossing the origin

	for (int i = 0; i < MAX_COMBO_LENGTH-1; i++) attackHistory[i] = attackHistory[i+1]; // Shift the history array
	attackHistory[MAX_COMBO_LENGTH-1] = job->attackType; // Add the latest attack to the history

	// Combo detection
	for (int i = 0; i < sizeof(COMBO_SEQUENCES) / sizeof(COMBO_SEQUENCES[0]); i++) {
		int32_t len = strlen(COMBO_SEQUENCES[i]);
		if (memcmp(COMBO_SEQUENCES[i], attackHistory+(MAX_COMBO_LENGTH-len), len) == 0) {
			// Combo detected
			comboCounter += COMBO_POINTS[i];
			buzzerState = (BuzzerState){200, 66, 3, CURRENT_TIME}; // Notify user about the combo
			comboBreak(); // so that overlapping combos won't be counted
		}
	}
	return true; // This type of job is always instantaneous
}

Job* acceptAttackRequests() {
	Job *ret = NULL, *j;
	if (risingEdge(BTN_LIGHT)) {
		ret = addLightAttack();
	} else if (risingEdge(BTN_HEAVY)) {
		chargingPermitted = true; // User must keep holding the button to retain this permission
		ret = addHeavyAttackCharger();
	} else if (risingEdge(BTN_SPECIAL) && comboCounter >= 3) {
		comboCounter = 0;
		addSpecialAttack();
	}
	if (ret != NULL) buzzerState = (BuzzerState){200, 66, 1, CURRENT_TIME}; // Notify user that an attack is accepted
	return ret;
}

// Below defines the actual animations

Job* addLightAttack() {
	Job *ret = NULL, *j;

	ret = j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_SIMPLE, 'L', RESTING_ANGLE, 0, 0, -1, 1000, POLY_EASE_IN, 2.5f, false, false};
	QueuePush(&jobQueue, j);

	j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_HIT, 'L'};
	QueuePush(&jobQueue, j);

	j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_SIMPLE, 'L', 0, RESTING_ANGLE, RESTING_ANGLE, -1, 1000, POLY_EASE_OUT, 2.5f, false, true};
	QueuePush(&jobQueue, j);

	return ret;
}
Job* addUnchargedHeavyAttack() {
	Job *ret = NULL, *j;

	ret = j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_SIMPLE, 'H', EXTENDED_ANGLE, 0, 0, -1, 800, POLY_EASE_IN, 2.5f, false, false};
	QueuePush(&jobQueue, j);

	j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_HIT, 'H'};
	QueuePush(&jobQueue, j);

	j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_SIMPLE, 'H', 0, RESTING_ANGLE, RESTING_ANGLE, -1, 800, POLY_EASE_OUT, 2.5f, false, true};
	QueuePush(&jobQueue, j);

	return ret;
}
Job* addChargedHeavyAttack() {
	Job *ret = NULL, *j;

	ret = j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_SIMPLE, 'C', EXTENDED_ANGLE, 0, 0, -1, 400, POLY_EASE_IN, 1.0f, false, false};
	QueuePush(&jobQueue, j);

	j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_HIT, 'C'};
	QueuePush(&jobQueue, j);

	j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_SIMPLE, 'C', 0, RESTING_ANGLE + CHARGED_OVERSHOOT_OFFSET, RESTING_ANGLE + CHARGED_OVERSHOOT_OFFSET, -1, 500, POLY_EASE_OUT, 1.2f, false, false};
	QueuePush(&jobQueue, j);

	j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_SIMPLE, 'C', RESTING_ANGLE + CHARGED_OVERSHOOT_OFFSET, RESTING_ANGLE, RESTING_ANGLE, -1, 1000, POLY_EASE_OUT, 2.5f, false, false};
	QueuePush(&jobQueue, j);

	return ret;
}
Job* addHeavyAttackCharger() {
	Job *ret = NULL;

	ret = (Job*)malloc(sizeof(Job));
	*ret = (Job){JOB_CHARGER, 'H', RESTING_ANGLE, EXTENDED_ANGLE, EXTENDED_ANGLE, -1, 500, POLY_EASE_IN_OUT, 2.0f, false, false, -1, false, false};
	QueuePush(&jobQueue, ret);

	return ret;
}
Job* addSpecialAttack() {
	Job *ret = NULL, *j;

	ret = j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_SIMPLE, 'S', RESTING_ANGLE, 0, 0, -1, 500, POLY_EASE_IN, 2.5f, false, false};
	QueuePush(&jobQueue, j);
	j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_HIT, 'S'};
	QueuePush(&jobQueue, j);
	ret = j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_SIMPLE, 'S', 0, M_PI/36, M_PI/36, -1, 100, POLY_EASE_OUT, 2.5f, false, false};
	QueuePush(&jobQueue, j);

	for (int i = 0; i < 16; i++) {
		ret = j = (Job*)malloc(sizeof(Job));
		*j = (Job){JOB_SIMPLE, 'S', M_PI/36, 0, 0, -1, 50, LINEAR, 2.5f, false, false};
		QueuePush(&jobQueue, j);
		j = (Job*)malloc(sizeof(Job));
		*j = (Job){JOB_HIT, 'S'};
		QueuePush(&jobQueue, j);
		ret = j = (Job*)malloc(sizeof(Job));
		*j = (Job){JOB_SIMPLE, 'S', 0, M_PI/36, M_PI/36, -1, 50, LINEAR, 2.5f, false, false};
		QueuePush(&jobQueue, j);
	}

	ret = j = (Job*)malloc(sizeof(Job));
	*j = (Job){JOB_SIMPLE, 'S', M_PI/36, RESTING_ANGLE, RESTING_ANGLE, -1, 500, POLY_EASE_OUT, 2.5f, false, false};
	QueuePush(&jobQueue, j);

	return ret;
}

