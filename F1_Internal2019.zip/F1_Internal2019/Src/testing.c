#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "lcd.h"
#include "camera.h"

uint8_t image[80*60] = {0};
uint16_t print[80*60] = {0};
char temp[17] = {0};

void uart1_rx(UART_HandleTypeDef* huart, const uint16_t byte) {
  // HAL_UART_Transmit(huart, &byte, 1, 0);
  static uint32_t idx = 0;
  temp[idx++] = byte;
  idx %= 16;
}

void test(void) {
  TIM1_PWM_Init();        //Initialize Motor PWM Timer
  TIM5_PWM_Init();        //Initialize Servo PWM Timer
  USART1_Init(115200);      //Initialize UART Port
  USART3_Init(115200);      //Initialize UART Port

  ADC_Start();

  HAL_UART_ReceiveBytes_IT(&huart1, uart1_rx);
  
  // while (CAM_Init() != CAM_CAPTURING);

  HAL_GPIO_InitPin(LED1_GPIO_Port, LED1_Pin, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL);
  HAL_GPIO_InitPin(LED2_GPIO_Port, LED2_Pin, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL);
  HAL_GPIO_InitPin(LED3_GPIO_Port, LED3_Pin, GPIO_MODE_OUTPUT_PP, GPIO_NOPULL);
  HAL_GPIO_InitPin(BUTTON1_GPIO_Port, BUTTON1_Pin, GPIO_MODE_INPUT, GPIO_PULLUP);
  HAL_GPIO_InitPin(BUTTON2_GPIO_Port, BUTTON2_Pin, GPIO_MODE_INPUT, GPIO_PULLUP);
  HAL_GPIO_InitPin(BUTTON3_GPIO_Port, BUTTON3_Pin, GPIO_MODE_INPUT, GPIO_PULLUP);
  tft_init(PIN_ON_TOP, BLACK, WHITE, YELLOW, RED);

  HAL_TIM_ConfigTimer(SERVO_TIM, 72, 20000);
  HAL_TIM_ConfigTimer(MOTOR_TIM, 72, 20000);

  HAL_TIM_PWM_SetCompare(MOTOR_TIM, TIM_CHANNEL_1, 2000);
  HAL_TIM_PWM_SetCompare(MOTOR_TIM, TIM_CHANNEL_2, 4000);
  HAL_TIM_PWM_SetCompare(MOTOR_TIM, TIM_CHANNEL_3, 6000);
  HAL_TIM_PWM_SetCompare(MOTOR_TIM, TIM_CHANNEL_4, 8000);
  HAL_TIM_PWM_SetCompare(SERVO_TIM, TIM_CHANNEL_1, 1500);
  HAL_TIM_PWM_SetCompare(SERVO_TIM, TIM_CHANNEL_2, 1500);
  HAL_TIM_PWM_SetCompare(SERVO_TIM, TIM_CHANNEL_3, 1500);

  HAL_TIM_PWM_Start(MOTOR_TIM, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(MOTOR_TIM, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(MOTOR_TIM, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(MOTOR_TIM, TIM_CHANNEL_4);
  HAL_TIM_PWM_Start(SERVO_TIM, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(SERVO_TIM, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(SERVO_TIM, TIM_CHANNEL_3);

  uint32_t frame_counter = 0;
  while (1)
  {
    static uint32_t servo_time = 1500;
    if (CAM_FrameReady()) {
      // HAL_GPIO_TogglePin(LED3_GPIO_Port, LED3_Pin);
      CAM_GetGrayscale(image);
      CAM_GreyToRGB565(image, print);
      frame_counter++;
    }

    if (tft_update2(50) == 0) {
      tft_printc(0, 0, "Hello World");
      tft_printi(0, 1, HAL_GetTick());
      tft_printi(0, 2, servo_time);
      tft_printi(0, 3, ADC_Values[0][0]);
      tft_printi(5, 3, ADC_Values[0][1]);
      tft_printi(0, 4, ADC_Values[0][2]);
      tft_printi(5, 4, ADC_Values[0][3]);
      tft_printc(0, 5, temp);
      // tft_printi(0, 3, CAM_FrameWidth());
      // tft_printi(0, 4, CAM_FrameHeight());
      tft_print_image(print, 0, 160-60, 80, 60);
    }

    static uint32_t last_tick = 0;
    if (HAL_GetTick() != last_tick) {
      last_tick = HAL_GetTick();

      static uint32_t last_blink1 = 0;
      if ((HAL_GetTick() - last_blink1) >= 50) {
        last_blink1 = HAL_GetTick();
        HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);

        HAL_TIM_PWM_SetCompare(SERVO_TIM, TIM_CHANNEL_1, servo_time);
        HAL_TIM_PWM_SetCompare(SERVO_TIM, TIM_CHANNEL_2, servo_time);
        HAL_TIM_PWM_SetCompare(SERVO_TIM, TIM_CHANNEL_3, servo_time);
        if (HAL_GPIO_ReadPin(BUTTON1_GPIO_Port, BUTTON1_Pin) == 0) 
          servo_time += 4;
        else if (HAL_GPIO_ReadPin(BUTTON2_GPIO_Port, BUTTON2_Pin) == 0) 
          servo_time -= 4;
      }
      static uint32_t last_blink2 = 0;
      if ((HAL_GetTick() - last_blink2) >= 200) {
        last_blink2 = HAL_GetTick();
        HAL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);
      }
    }
  }
}
