/**
 ******************************************************************************
 * File Name          : TIM.c
 * Description        : This file provides code for the configuration
 *                      of the TIM instances.
 ******************************************************************************
 * @attention
 *
 * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
 * All rights reserved.</center></h2>
 *
 * This software component is licensed by ST under BSD 3-Clause license,
 * the "License"; You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                        opensource.org/licenses/BSD-3-Clause
 *
 ******************************************************************************
 */

/* Includes ------------------------------------------------------------------*/
#include "tim.h"

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;
TIM_HandleTypeDef htim5;
TIM_HandleTypeDef htim6;
TIM_HandleTypeDef htim7;
TIM_HandleTypeDef htim8;

/* TIM1 init function */
void TIM1_PWM_Init(void) {
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };
	TIM_OC_InitTypeDef sConfigOC = { 0 };
	TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = { 0 };

	htim1.Instance = TIM1;
	// htim1.Init.Prescaler = 71;
	htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
	// htim1.Init.Period = 19999;
	htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim1.Init.RepetitionCounter = 0;
	htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_PWM_Init(&htim1) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK) {
		Error_Handler();
	}
	sConfigOC.OCMode = TIM_OCMODE_PWM1;
	sConfigOC.Pulse = 0;
	sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
	sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
	sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
	sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
	sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
	if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK) {
		Error_Handler();
	}
	if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK) {
		Error_Handler();
	}
	if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_3) != HAL_OK) {
		Error_Handler();
	}
	if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_4) != HAL_OK) {
		Error_Handler();
	}
	sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
	sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
	sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
	sBreakDeadTimeConfig.DeadTime = 0;
	sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
	sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
	sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
	if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK) {
		Error_Handler();
	}
	HAL_TIM_MspPostInit(&htim1);

}
/* TIM3 init function */
void TIM3_IC_Init(void) {
	TIM_ClockConfigTypeDef sClockSourceConfig = { 0 };
	TIM_SlaveConfigTypeDef sSlaveConfig = { 0 };
	TIM_IC_InitTypeDef sConfigIC = { 0 };
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };

	htim3.Instance = TIM3;
	htim3.Init.Prescaler = 0;
	htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim3.Init.Period = 0;
	htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim3) != HAL_OK) {
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK) {
		Error_Handler();
	}
	if (HAL_TIM_IC_Init(&htim3) != HAL_OK) {
		Error_Handler();
	}
	sSlaveConfig.SlaveMode = TIM_SLAVEMODE_RESET;
	sSlaveConfig.InputTrigger = TIM_TS_TI1FP1;
	sSlaveConfig.TriggerPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
	sSlaveConfig.TriggerPrescaler = TIM_ICPSC_DIV1;
	sSlaveConfig.TriggerFilter = 0;
	if (HAL_TIM_SlaveConfigSynchro(&htim3, &sSlaveConfig) != HAL_OK) {
		Error_Handler();
	}
	sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
	sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
	sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
	sConfigIC.ICFilter = 0;
	if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_1) != HAL_OK) {
		Error_Handler();
	}
	sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
	sConfigIC.ICSelection = TIM_ICSELECTION_INDIRECTTI;
	if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_2) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK) {
		Error_Handler();
	}

}
/* TIM4 init function */
void TIM4_IC_Init(void) {
	TIM_ClockConfigTypeDef sClockSourceConfig = { 0 };
	TIM_SlaveConfigTypeDef sSlaveConfig = { 0 };
	TIM_IC_InitTypeDef sConfigIC = { 0 };
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };

	htim4.Instance = TIM4;
	htim4.Init.Prescaler = 0;
	htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim4.Init.Period = 0;
	htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim4) != HAL_OK) {
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig) != HAL_OK) {
		Error_Handler();
	}
	if (HAL_TIM_IC_Init(&htim4) != HAL_OK) {
		Error_Handler();
	}
	sSlaveConfig.SlaveMode = TIM_SLAVEMODE_RESET;
	sSlaveConfig.InputTrigger = TIM_TS_TI1FP1;
	sSlaveConfig.TriggerPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
	sSlaveConfig.TriggerPrescaler = TIM_ICPSC_DIV1;
	sSlaveConfig.TriggerFilter = 0;
	if (HAL_TIM_SlaveConfigSynchro(&htim4, &sSlaveConfig) != HAL_OK) {
		Error_Handler();
	}
	sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
	sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
	sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
	sConfigIC.ICFilter = 0;
	if (HAL_TIM_IC_ConfigChannel(&htim4, &sConfigIC, TIM_CHANNEL_1) != HAL_OK) {
		Error_Handler();
	}
	sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
	sConfigIC.ICSelection = TIM_ICSELECTION_INDIRECTTI;
	if (HAL_TIM_IC_ConfigChannel(&htim4, &sConfigIC, TIM_CHANNEL_2) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK) {
		Error_Handler();
	}

}
/* TIM3 init function */
void TIM3_ENC_Init(void) {
	TIM_Encoder_InitTypeDef sConfig = { 0 };
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };

	htim3.Instance = TIM3;
	htim3.Init.Prescaler = 0;
	htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim3.Init.Period = 0;
	htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	sConfig.EncoderMode = TIM_ENCODERMODE_TI1;
	sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
	sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
	sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
	sConfig.IC1Filter = 0;
	sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
	sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
	sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
	sConfig.IC2Filter = 0;
	if (HAL_TIM_Encoder_Init(&htim3, &sConfig) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK) {
		Error_Handler();
	}

}
/* TIM4 init function */
void TIM4_ENC_Init(void) {
	TIM_Encoder_InitTypeDef sConfig = { 0 };
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };

	htim4.Instance = TIM4;
	htim4.Init.Prescaler = 0;
	htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim4.Init.Period = 0;
	htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	sConfig.EncoderMode = TIM_ENCODERMODE_TI1;
	sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
	sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
	sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
	sConfig.IC1Filter = 0;
	sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
	sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
	sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
	sConfig.IC2Filter = 0;
	if (HAL_TIM_Encoder_Init(&htim4, &sConfig) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK) {
		Error_Handler();
	}

}
/* TIM5 init function */
void TIM5_PWM_Init(void) {
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };
	TIM_OC_InitTypeDef sConfigOC = { 0 };

	htim5.Instance = TIM5;
	// htim5.Init.Prescaler = 0;
	htim5.Init.CounterMode = TIM_COUNTERMODE_UP;
	// htim5.Init.Period = 0;
	htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim5.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_PWM_Init(&htim5) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim5, &sMasterConfig) != HAL_OK) {
		Error_Handler();
	}
	sConfigOC.OCMode = TIM_OCMODE_PWM1;
	sConfigOC.Pulse = 0;
	sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
	sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
	if (HAL_TIM_PWM_ConfigChannel(&htim5, &sConfigOC, TIM_CHANNEL_1) != HAL_OK) {
		Error_Handler();
	}
	if (HAL_TIM_PWM_ConfigChannel(&htim5, &sConfigOC, TIM_CHANNEL_2) != HAL_OK) {
		Error_Handler();
	}
	if (HAL_TIM_PWM_ConfigChannel(&htim5, &sConfigOC, TIM_CHANNEL_3) != HAL_OK) {
		Error_Handler();
	}
	HAL_TIM_MspPostInit(&htim5);

}
/* TIM6 init function */
void TIM6_Init(void) {
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };

	htim6.Instance = TIM6;
	htim6.Init.Prescaler = 0;
	htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim6.Init.Period = 0;
	htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim6) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK) {
		Error_Handler();
	}

}
/* TIM7 init function */
void TIM7_Init(void) {
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };

	htim7.Instance = TIM7;
	htim7.Init.Prescaler = 0;
	htim7.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim7.Init.Period = 0;
	htim7.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim7) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim7, &sMasterConfig) != HAL_OK) {
		Error_Handler();
	}

}
/* TIM8 init function */
void TIM8_IC_Init(void) {
	TIM_ClockConfigTypeDef sClockSourceConfig = { 0 };
	TIM_SlaveConfigTypeDef sSlaveConfig = { 0 };
	TIM_IC_InitTypeDef sConfigIC = { 0 };
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };

	htim8.Instance = TIM8;
	htim8.Init.Prescaler = 0;
	htim8.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim8.Init.Period = 0;
	htim8.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim8.Init.RepetitionCounter = 0;
	htim8.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim8) != HAL_OK) {
		Error_Handler();
	}
	sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
	if (HAL_TIM_ConfigClockSource(&htim8, &sClockSourceConfig) != HAL_OK) {
		Error_Handler();
	}
	if (HAL_TIM_IC_Init(&htim8) != HAL_OK) {
		Error_Handler();
	}
	sSlaveConfig.SlaveMode = TIM_SLAVEMODE_RESET;
	sSlaveConfig.InputTrigger = TIM_TS_TI1FP1;
	sSlaveConfig.TriggerPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
	sSlaveConfig.TriggerPrescaler = TIM_ICPSC_DIV1;
	sSlaveConfig.TriggerFilter = 0;
	if (HAL_TIM_SlaveConfigSynchro(&htim8, &sSlaveConfig) != HAL_OK) {
		Error_Handler();
	}
	sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
	sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
	sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
	sConfigIC.ICFilter = 0;
	if (HAL_TIM_IC_ConfigChannel(&htim8, &sConfigIC, TIM_CHANNEL_1) != HAL_OK) {
		Error_Handler();
	}
	sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_FALLING;
	sConfigIC.ICSelection = TIM_ICSELECTION_INDIRECTTI;
	if (HAL_TIM_IC_ConfigChannel(&htim8, &sConfigIC, TIM_CHANNEL_2) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim8, &sMasterConfig) != HAL_OK) {
		Error_Handler();
	}

}
/* TIM8 init function */
void TIM8_ENC_Init(void) {
	TIM_Encoder_InitTypeDef sConfig = { 0 };
	TIM_MasterConfigTypeDef sMasterConfig = { 0 };

	htim8.Instance = TIM8;
	htim8.Init.Prescaler = 0;
	htim8.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim8.Init.Period = 0;
	htim8.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim8.Init.RepetitionCounter = 0;
	htim8.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	sConfig.EncoderMode = TIM_ENCODERMODE_TI1;
	sConfig.IC1Polarity = TIM_ICPOLARITY_RISING;
	sConfig.IC1Selection = TIM_ICSELECTION_DIRECTTI;
	sConfig.IC1Prescaler = TIM_ICPSC_DIV1;
	sConfig.IC1Filter = 0;
	sConfig.IC2Polarity = TIM_ICPOLARITY_RISING;
	sConfig.IC2Selection = TIM_ICSELECTION_DIRECTTI;
	sConfig.IC2Prescaler = TIM_ICPSC_DIV1;
	sConfig.IC2Filter = 0;
	if (HAL_TIM_Encoder_Init(&htim8, &sConfig) != HAL_OK) {
		Error_Handler();
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim8, &sMasterConfig) != HAL_OK) {
		Error_Handler();
	}

}

void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef* tim_pwmHandle) {

	if (tim_pwmHandle->Instance == TIM1) {
		/* USER CODE BEGIN TIM1_MspInit 0 */

		/* USER CODE END TIM1_MspInit 0 */
		/* TIM1 clock enable */
		__HAL_RCC_TIM1_CLK_ENABLE()
		;
		/* USER CODE BEGIN TIM1_MspInit 1 */

		/* USER CODE END TIM1_MspInit 1 */
	} else
		if (tim_pwmHandle->Instance == TIM5) {
			/* USER CODE BEGIN TIM5_MspInit 0 */

			/* USER CODE END TIM5_MspInit 0 */
			/* TIM5 clock enable */
			__HAL_RCC_TIM5_CLK_ENABLE()
			;
			/* USER CODE BEGIN TIM5_MspInit 1 */

			/* USER CODE END TIM5_MspInit 1 */
		}
}
void HAL_TIM_Encoder_MspInit(TIM_HandleTypeDef* tim_encoderHandle) {

	GPIO_InitTypeDef GPIO_InitStruct = { 0 };
	if (tim_encoderHandle->Instance == TIM3) {
		/* USER CODE BEGIN TIM3_MspInit 0 */

		/* USER CODE END TIM3_MspInit 0 */
		/* TIM3 clock enable */
		__HAL_RCC_TIM3_CLK_ENABLE()
		;

		__HAL_RCC_GPIOB_CLK_ENABLE()
		;
		/**TIM3 GPIO Configuration
		 PB4     ------> TIM3_CH1
		 PB5     ------> TIM3_CH2
		 */
		GPIO_InitStruct.Pin = ENC2A_Pin | ENC2B_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

		__HAL_AFIO_REMAP_TIM3_PARTIAL()
		;

		/* USER CODE BEGIN TIM3_MspInit 1 */

		/* USER CODE END TIM3_MspInit 1 */
	} else
		if (tim_encoderHandle->Instance == TIM4) {
			/* USER CODE BEGIN TIM4_MspInit 0 */

			/* USER CODE END TIM4_MspInit 0 */
			/* TIM4 clock enable */
			__HAL_RCC_TIM4_CLK_ENABLE()
			;

			__HAL_RCC_GPIOB_CLK_ENABLE()
			;
			/**TIM4 GPIO Configuration
			 PB6     ------> TIM4_CH1
			 PB7     ------> TIM4_CH2
			 */
			GPIO_InitStruct.Pin = ENC1A_Pin | ENC1B_Pin;
			GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
			GPIO_InitStruct.Pull = GPIO_NOPULL;
			HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

			/* USER CODE BEGIN TIM4_MspInit 1 */

			/* USER CODE END TIM4_MspInit 1 */
		} else
			if (tim_encoderHandle->Instance == TIM8) {
				/* USER CODE BEGIN TIM8_MspInit 0 */

				/* USER CODE END TIM8_MspInit 0 */
				/* TIM8 clock enable */
				__HAL_RCC_TIM8_CLK_ENABLE()
				;

				__HAL_RCC_GPIOC_CLK_ENABLE()
				;
				/**TIM8 GPIO Configuration
				 PC6     ------> TIM8_CH1
				 PC7     ------> TIM8_CH2
				 */
				GPIO_InitStruct.Pin = ENC3B_Pin | ENC3A_Pin;
				GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
				GPIO_InitStruct.Pull = GPIO_NOPULL;
				HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

				/* USER CODE BEGIN TIM8_MspInit 1 */

				/* USER CODE END TIM8_MspInit 1 */
			}
}

void HAL_TIM_Base_MspInit(TIM_HandleTypeDef* tim_baseHandle) {

	GPIO_InitTypeDef GPIO_InitStruct = { 0 };
	if (tim_baseHandle->Instance == TIM3) {
		/* USER CODE BEGIN TIM3_MspInit 0 */

		/* USER CODE END TIM3_MspInit 0 */
		/* TIM3 clock enable */
		__HAL_RCC_TIM3_CLK_ENABLE()
		;

		__HAL_RCC_GPIOB_CLK_ENABLE()
		;
		/**TIM3 GPIO Configuration
		 PB4     ------> TIM3_CH1
		 */
		GPIO_InitStruct.Pin = PWMI2_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		HAL_GPIO_Init(PWMI2_GPIO_Port, &GPIO_InitStruct);

		__HAL_AFIO_REMAP_TIM3_PARTIAL()
		;

		/* USER CODE BEGIN TIM3_MspInit 1 */

		/* USER CODE END TIM3_MspInit 1 */
	} else
		if (tim_baseHandle->Instance == TIM4) {
			/* USER CODE BEGIN TIM4_MspInit 0 */

			/* USER CODE END TIM4_MspInit 0 */
			/* TIM4 clock enable */
			__HAL_RCC_TIM4_CLK_ENABLE()
			;

			__HAL_RCC_GPIOB_CLK_ENABLE()
			;
			/**TIM4 GPIO Configuration
			 PB6     ------> TIM4_CH1
			 */
			GPIO_InitStruct.Pin = PWMI1_Pin;
			GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
			GPIO_InitStruct.Pull = GPIO_NOPULL;
			HAL_GPIO_Init(PWMI1_GPIO_Port, &GPIO_InitStruct);

			/* USER CODE BEGIN TIM4_MspInit 1 */

			/* USER CODE END TIM4_MspInit 1 */
		} else
			if (tim_baseHandle->Instance == TIM6) {
				/* USER CODE BEGIN TIM6_MspInit 0 */

				/* USER CODE END TIM6_MspInit 0 */
				/* TIM6 clock enable */
				__HAL_RCC_TIM6_CLK_ENABLE()
				;
				/* USER CODE BEGIN TIM6_MspInit 1 */

				/* USER CODE END TIM6_MspInit 1 */
			} else
				if (tim_baseHandle->Instance == TIM7) {
					/* USER CODE BEGIN TIM7_MspInit 0 */

					/* USER CODE END TIM7_MspInit 0 */
					/* TIM7 clock enable */
					__HAL_RCC_TIM7_CLK_ENABLE()
					;
					/* USER CODE BEGIN TIM7_MspInit 1 */

					/* USER CODE END TIM7_MspInit 1 */
				} else
					if (tim_baseHandle->Instance == TIM8) {
						/* USER CODE BEGIN TIM8_MspInit 0 */

						/* USER CODE END TIM8_MspInit 0 */
						/* TIM8 clock enable */
						__HAL_RCC_TIM8_CLK_ENABLE()
						;

						__HAL_RCC_GPIOC_CLK_ENABLE()
						;
						/**TIM8 GPIO Configuration
						 PC6     ------> TIM8_CH1
						 */
						GPIO_InitStruct.Pin = PWMI3_Pin;
						GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
						GPIO_InitStruct.Pull = GPIO_NOPULL;
						HAL_GPIO_Init(PWMI3_GPIO_Port, &GPIO_InitStruct);

						/* USER CODE BEGIN TIM8_MspInit 1 */

						/* USER CODE END TIM8_MspInit 1 */
					}
}
void HAL_TIM_MspPostInit(TIM_HandleTypeDef* timHandle) {

	GPIO_InitTypeDef GPIO_InitStruct = { 0 };
	if (timHandle->Instance == TIM1) {
		/* USER CODE BEGIN TIM1_MspPostInit 0 */

		/* USER CODE END TIM1_MspPostInit 0 */
		__HAL_RCC_GPIOE_CLK_ENABLE()
		;
		/**TIM1 GPIO Configuration
		 PE9     ------> TIM1_CH1
		 PE11     ------> TIM1_CH2
		 PE13     ------> TIM1_CH3
		 PE14     ------> TIM1_CH4
		 */
		GPIO_InitStruct.Pin = M1_PWM_Pin | M2_PWM_Pin | M3_PWM_Pin | M4_PWM_Pin;
		GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
		HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

		__HAL_AFIO_REMAP_TIM1_ENABLE()
		;

		/* USER CODE BEGIN TIM1_MspPostInit 1 */

		/* USER CODE END TIM1_MspPostInit 1 */
	} else
		if (timHandle->Instance == TIM5) {
			/* USER CODE BEGIN TIM5_MspPostInit 0 */

			/* USER CODE END TIM5_MspPostInit 0 */

			__HAL_RCC_GPIOA_CLK_ENABLE()
			;
			/**TIM5 GPIO Configuration
			 PA0-WKUP     ------> TIM5_CH1
			 PA1     ------> TIM5_CH2
			 PA2     ------> TIM5_CH3
			 */
			GPIO_InitStruct.Pin = SERVO1_Pin | SERVO2_Pin | SERVO3_Pin;
			GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
			GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
			HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

			/* USER CODE BEGIN TIM5_MspPostInit 1 */

			/* USER CODE END TIM5_MspPostInit 1 */
		}

}

void HAL_TIM_PWM_MspDeInit(TIM_HandleTypeDef* tim_pwmHandle) {

	if (tim_pwmHandle->Instance == TIM1) {
		/* USER CODE BEGIN TIM1_MspDeInit 0 */

		/* USER CODE END TIM1_MspDeInit 0 */
		/* Peripheral clock disable */
		__HAL_RCC_TIM1_CLK_DISABLE();
		/* USER CODE BEGIN TIM1_MspDeInit 1 */

		/* USER CODE END TIM1_MspDeInit 1 */
	} else
		if (tim_pwmHandle->Instance == TIM5) {
			/* USER CODE BEGIN TIM5_MspDeInit 0 */

			/* USER CODE END TIM5_MspDeInit 0 */
			/* Peripheral clock disable */
			__HAL_RCC_TIM5_CLK_DISABLE();
			/* USER CODE BEGIN TIM5_MspDeInit 1 */

			/* USER CODE END TIM5_MspDeInit 1 */
		}
}

void HAL_TIM_Encoder_MspDeInit(TIM_HandleTypeDef* tim_encoderHandle) {

	if (tim_encoderHandle->Instance == TIM3) {
		/* USER CODE BEGIN TIM3_MspDeInit 0 */

		/* USER CODE END TIM3_MspDeInit 0 */
		/* Peripheral clock disable */
		__HAL_RCC_TIM3_CLK_DISABLE();

		/**TIM3 GPIO Configuration
		 PB4     ------> TIM3_CH1
		 PB5     ------> TIM3_CH2
		 */
		HAL_GPIO_DeInit(GPIOB, ENC2A_Pin | ENC2B_Pin);

		/* USER CODE BEGIN TIM3_MspDeInit 1 */

		/* USER CODE END TIM3_MspDeInit 1 */
	} else
		if (tim_encoderHandle->Instance == TIM4) {
			/* USER CODE BEGIN TIM4_MspDeInit 0 */

			/* USER CODE END TIM4_MspDeInit 0 */
			/* Peripheral clock disable */
			__HAL_RCC_TIM4_CLK_DISABLE();

			/**TIM4 GPIO Configuration
			 PB6     ------> TIM4_CH1
			 PB7     ------> TIM4_CH2
			 */
			HAL_GPIO_DeInit(GPIOB, ENC1A_Pin | ENC1B_Pin);

			/* USER CODE BEGIN TIM4_MspDeInit 1 */

			/* USER CODE END TIM4_MspDeInit 1 */
		} else
			if (tim_encoderHandle->Instance == TIM8) {
				/* USER CODE BEGIN TIM8_MspDeInit 0 */

				/* USER CODE END TIM8_MspDeInit 0 */
				/* Peripheral clock disable */
				__HAL_RCC_TIM8_CLK_DISABLE();

				/**TIM8 GPIO Configuration
				 PC6     ------> TIM8_CH1
				 PC7     ------> TIM8_CH2
				 */
				HAL_GPIO_DeInit(GPIOC, ENC3B_Pin | ENC3A_Pin);

				/* USER CODE BEGIN TIM8_MspDeInit 1 */

				/* USER CODE END TIM8_MspDeInit 1 */
			}
}

void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef* tim_baseHandle) {

	if (tim_baseHandle->Instance == TIM3) {
		/* USER CODE BEGIN TIM3_MspDeInit 0 */

		/* USER CODE END TIM3_MspDeInit 0 */
		/* Peripheral clock disable */
		__HAL_RCC_TIM3_CLK_DISABLE();

		/**TIM3 GPIO Configuration
		 PB4     ------> TIM3_CH1
		 */
		HAL_GPIO_DeInit(PWMI2_GPIO_Port, PWMI2_Pin);

		/* USER CODE BEGIN TIM3_MspDeInit 1 */

		/* USER CODE END TIM3_MspDeInit 1 */
	} else
		if (tim_baseHandle->Instance == TIM4) {
			/* USER CODE BEGIN TIM4_MspDeInit 0 */

			/* USER CODE END TIM4_MspDeInit 0 */
			/* Peripheral clock disable */
			__HAL_RCC_TIM4_CLK_DISABLE();

			/**TIM4 GPIO Configuration
			 PB6     ------> TIM4_CH1
			 */
			HAL_GPIO_DeInit(PWMI1_GPIO_Port, PWMI1_Pin);

			/* USER CODE BEGIN TIM4_MspDeInit 1 */

			/* USER CODE END TIM4_MspDeInit 1 */
		} else
			if (tim_baseHandle->Instance == TIM6) {
				/* USER CODE BEGIN TIM6_MspDeInit 0 */

				/* USER CODE END TIM6_MspDeInit 0 */
				/* Peripheral clock disable */
				__HAL_RCC_TIM6_CLK_DISABLE();
				/* USER CODE BEGIN TIM6_MspDeInit 1 */

				/* USER CODE END TIM6_MspDeInit 1 */
			} else
				if (tim_baseHandle->Instance == TIM7) {
					/* USER CODE BEGIN TIM7_MspDeInit 0 */

					/* USER CODE END TIM7_MspDeInit 0 */
					/* Peripheral clock disable */
					__HAL_RCC_TIM7_CLK_DISABLE();
					/* USER CODE BEGIN TIM7_MspDeInit 1 */

					/* USER CODE END TIM7_MspDeInit 1 */
				} else
					if (tim_baseHandle->Instance == TIM8) {
						/* USER CODE BEGIN TIM8_MspDeInit 0 */

						/* USER CODE END TIM8_MspDeInit 0 */
						/* Peripheral clock disable */
						__HAL_RCC_TIM8_CLK_DISABLE();

						/**TIM8 GPIO Configuration
						 PC6     ------> TIM8_CH1
						 */
						HAL_GPIO_DeInit(PWMI3_GPIO_Port, PWMI3_Pin);

						/* USER CODE BEGIN TIM8_MspDeInit 1 */

						/* USER CODE END TIM8_MspDeInit 1 */
					}
}

/* USER CODE BEGIN 1 */
void HAL_TIM_ConfigTimer(TIM_HandleTypeDef* htim, uint16_t prescaler, uint16_t autoreload) {
	__HAL_TIM_SET_PRESCALER(htim, prescaler);
	__HAL_TIM_SET_AUTORELOAD(htim, autoreload);
}
void HAL_TIM_PWM_SetCompare(TIM_HandleTypeDef* htim, uint32_t channel, uint16_t compare) {
	__HAL_TIM_SET_COMPARE(htim, channel, compare);
}
uint16_t HAL_TIM_PWM_GetCapture(TIM_HandleTypeDef* htim, uint32_t channel) {
	return __HAL_TIM_GET_COMPARE(htim, channel);
}
/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
